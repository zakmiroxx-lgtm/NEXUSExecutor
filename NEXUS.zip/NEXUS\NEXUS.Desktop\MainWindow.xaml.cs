using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;

namespace NEXUS.Desktop;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();

        Log("NEXUS initialized.");
        Log("Ready.");
    }

    private void Log(string message)
    {
        ConsoleBox.AppendText(
            $"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}"
        );

        ConsoleBox.ScrollToEnd();
    }

    private void Attach_Click(
        object sender,
        RoutedEventArgs e)
    {
        try
        {
            bool found = Process
                .GetProcesses()
                .Any(p =>
                {
                    try
                    {
                        return p.ProcessName.Contains(
                            "Roblox",
                            StringComparison.OrdinalIgnoreCase
                        );
                    }
                    catch
                    {
                        return false;
                    }
                });

            if (found)
            {
                StatusText.Text = "ROBLOX DETECTED";
                StatusText.Foreground = Brushes.Orange;

                Log("Roblox process detected.");
                Log("Execution bridge is not configured.");
            }
            else
            {
                StatusText.Text = "ROBLOX NOT FOUND";
                StatusText.Foreground = Brushes.Red;

                Log("Roblox process not found.");
            }
        }
        catch (Exception ex)
        {
            Log($"Detection error: {ex.Message}");
        }
    }

    private void ExecuteClient_Click(
        object sender,
        RoutedEventArgs e)
    {
        Log("Client execution unavailable.");
        Log("A supported Luau execution bridge is required.");
    }

    private void ExecuteServer_Click(
        object sender,
        RoutedEventArgs e)
    {
        Log("SERVER ACCESS UNAVAILABLE.");
        Log("No authorized server component connected.");
    }

    private void CheckServer_Click(
        object sender,
        RoutedEventArgs e)
    {
        ServerStatus.Text = "SERVER ACCESS: UNAVAILABLE";
        Log("Server bridge is not configured.");
    }

    private void ClearClient_Click(
        object sender,
        RoutedEventArgs e)
    {
        ClientEditor.Clear();
    }

    private void ClearServer_Click(
        object sender,
        RoutedEventArgs e)
    {
        ServerEditor.Clear();
    }

    private void OpenClient_Click(
        object sender,
        RoutedEventArgs e)
    {
        OpenScript(ClientEditor);
    }

    private void OpenServer_Click(
        object sender,
        RoutedEventArgs e)
    {
        OpenScript(ServerEditor);
    }

    private void SaveClient_Click(
        object sender,
        RoutedEventArgs e)
    {
        SaveScript(ClientEditor);
    }

    private void SaveServer_Click(
        object sender,
        RoutedEventArgs e)
    {
        SaveScript(ServerEditor);
    }

    private void OpenScript(
        System.Windows.Controls.TextBox editor)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Luau Scripts|*.lua;*.luau|All Files|*.*"
        };

        if (dialog.ShowDialog() == true)
        {
            try
            {
                editor.Text = File.ReadAllText(dialog.FileName);
                Log($"Loaded: {dialog.FileName}");
            }
            catch (Exception ex)
            {
                Log($"Open error: {ex.Message}");
            }
        }
    }

    private void SaveScript(
        System.Windows.Controls.TextBox editor)
    {
        var dialog = new SaveFileDialog
        {
            Filter = "Luau Scripts|*.luau|Lua Scripts|*.lua",
            FileName = "script.luau"
        };

        if (dialog.ShowDialog() == true)
        {
            try
            {
                File.WriteAllText(
                    dialog.FileName,
                    editor.Text
                );

                Log($"Saved: {dialog.FileName}");
            }
            catch (Exception ex)
            {
                Log($"Save error: {ex.Message}");
            }
        }
    }
}