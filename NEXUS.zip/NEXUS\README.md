# NEXUS Universal Executor

Windows WPF application built with .NET 8.

## Features

- Roblox process detection.
- Client-Side Luau editor.
- Server-Side Luau editor.
- Script loading and saving.
- Execution console.
- GitHub Actions build support.

## Build

Upload NEXUS.zip to GitHub.

Create .github/workflows/build.yml
using the separately provided workflow.

Run the workflow from GitHub Actions.

## Limitations

This version does not execute Luau scripts in Roblox.