using System.Windows;

namespace NEXUS.Desktop;

public partial class App : Application
{
}